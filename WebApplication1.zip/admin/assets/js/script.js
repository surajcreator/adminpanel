﻿$(document).ready(function () {
    var windowHeight = $(window).height();
    var bodyHeight = $('body').height();
    var mainHeaderHeight = $('.main-header').height();

    tinymce.init({ selector: '.tiny' });

    $('.left-side-nav').css({ 'min-height': bodyHeight });

    $('body').on('click', '.side-nav li .has-submenu', function (e) {
        e.preventDefault();
        $(this).siblings('.nav-submenu').toggle();
        if ($(this).siblings('.nav-submenu').is(':visible')) {
            $(this).find('.extend-menu i').text('remove');
        } else {
            $(this).find('.extend-menu i').text('add');
        }
    });

    $('body').on('click', '.user-avtar', function () {
        $('.header-submenu').slideToggle();
    });

    $('.page-content').css({ 'top': mainHeaderHeight});
});